<?php
$con=mysqli_connect("localhost", "root", "", "phpcrud");
if(!$con)
{
echo "Connection Fail".mysqli_connect_error();
}
?>