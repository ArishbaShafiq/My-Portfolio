<?php

include('connection.php');

if (isset($_POST['submit'])) {
    //getting the post values
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    // Query for data insertion
    $query = mysqli_query($conn, "insert into students (name, email, phone, course) value('$name','$email', '$phone', '$course' )");
    if ($query) {
        echo "<script>
            alert('Data submitted successfully!');
          </script>";

          echo "<script>window.location.href = 'index.php';</script>";

        // echo "<script type='text/javascript'> document.location ='read1.php'; </script>";
    } else {
        echo "<script>
                alert('Something Went Wrong! Please try again.');
            </script>";
    }
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Student Data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <!-- Optional: Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="form-container">
        <h2>Add Student</h2>
        <form method="POST">
            <div class="form-group">
                <input type="text" name="name" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="tel" name="phone" placeholder="Phone" required>
            </div>
            <div class="form-group">
                <input type="text" name="course" placeholder="Course" required>
            </div>
            <button type="submit" name="submit" class="btn-gradient"><a class="link" href="index.php">Add</a></button>
        </form>
    </div>

</body>

</html>