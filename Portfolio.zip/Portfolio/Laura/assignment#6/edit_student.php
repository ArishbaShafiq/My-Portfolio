<?php
//Database Connection
include 'connection.php';
if (isset($_POST['submit'])) {
    $eid = $_GET['editid'];
    //Getting Post Values
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    //Query for data updation
    $query = mysqli_query($conn, "update  students set name='$name', email='$email', phone='$phone', course='$course' where ID='$eid'");

    if ($query) {
        echo "<script>alert('Data updated successfully!');</script>";
        echo "<script type='text/javascript'> document.location ='index.php'; </script>";
    } else {
        echo "<script>alert('Something Went Wrong! Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Student Data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <!-- Optional: Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="form-container">
        <h2>Update</h2>
        <form method="POST">
            <?php
            $eid = $_GET['editid'];
            $ret = mysqli_query($conn, "select * from students where ID='$eid'");
            while ($row = mysqli_fetch_array($ret)) {
                ?>
                <div class="form-group">
                    <input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Full Name" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="tel" name="phone" value="<?php echo $row['phone']; ?>" placeholder="Phone" required>
                </div>
                <div class="form-group">
                    <input type="text" name="course" value="<?php echo $row['course']; ?>" placeholder="Course" required>
                </div>
                <?php
            }
            ?>
            <button type="submit" name="submit" class="btn-gradient"><a class="link" href="index.php">Update</a></button>
        </form>
    </div>

</body>

</html>