Student Management System - PHP CRUD

How to Run:
1. Place folder in htdocs (if using XAMPP).
2. Create database `student_db` and table `students` with fields: id (AUTO_INCREMENT), name, email, phone, course.
3. Update credentials in db_conn.php if needed.
4. Run `index.php` from browser.
5. edit_student.php to update student record.
6. delete_student.php , deleted unwanted student record.
7. read.php to get student records.

Files:
- index.php: View students
- add_student.php: Add new student
- edit_student.php: Update student info
- delete_student.php: Delete student
- db_conn.php: DB Connection

Bonus: Bootstrap used for styling
