<?php
include('connection.php');

// Fetch all student records
$query = mysqli_query($conn, "SELECT * FROM students");

$search = '';
if (isset($_GET['search'])) {
  $search = mysqli_real_escape_string($conn, $_GET['search']);
  $query = mysqli_query($conn, "SELECT * FROM students WHERE name LIKE '%$search%' OR email LIKE '%$search%' OR course LIKE '%$search%'");
} else {
  $query = mysqli_query($conn, "SELECT * FROM students");
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Students List</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <!-- Optional: Bootstrap + Font Awesome -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>

<body>

  <div class="table-container">
    
    <div class="top-bar d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
  <h2 class="mb-0" style="font-weight: 600;">Students List</h2>

  <div class="d-flex align-items-center gap-2">
    <form class="d-flex align-items-center gap-2" method="GET" action="">
      <input class="form-control" type="search" name="search"
        value="<?php echo htmlspecialchars($search); ?>"
        placeholder="Search..." aria-label="Search"
        style="max-width: 200px; font-size: 0.9rem; padding: 6px 10px;">
      <button class="btn-add" type="submit" style="padding: 6px 15px; font-size: 0.9rem; display:flex;">
        <i class="fas fa-search me-1 mt-1"></i>Search
      </button>
    </form>

    <a href="add_student.php" class="btn-add" style="padding: 6px 15px; font-size: 0.9rem;">
      <i class="fas fa-user-plus me-1"></i>Add
    </a>
  </div>
</div>


    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Course</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sr = 1;
        while ($row = mysqli_fetch_assoc($query)) {
          echo "<tr>
              <td>{$sr}</td>
              <td>{$row['name']}</td>
              <td>{$row['email']}</td>
              <td>{$row['phone']}</td>
              <td>{$row['course']}</td>
              <td>
                <a href='edit_student.php?editid=" . htmlentities($row['id']) . "' class='btn-action edit'><i class='fas fa-edit'></i></a>
                <a href='delete_student.php?delid=" . $row['id'] . "' class='btn-action delete' onclick=\"return confirm('Are you sure you want to delete this record?');\"><i class='fas fa-trash-alt'></i></a>
              </td>
              </tr>";
          $sr++;
        }

        if (mysqli_num_rows($query) === 0) {
          echo "<tr><td colspan='6'>No matching records found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>

</html>