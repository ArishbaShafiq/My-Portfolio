<?php
include('connection.php');

// Code for deletion
if (isset($_GET['delid'])) {
    $rid = intval($_GET['delid']);
    $sql = mysqli_query($conn, "DELETE FROM students WHERE id = $rid");

    if ($sql) {
        echo "<script>alert('Data deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting data.');</script>";
    }

    echo "<script>window.location.href = 'index.php';</script>";
}
?>